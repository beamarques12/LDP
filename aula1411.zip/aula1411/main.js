function visualizar(pagina){
    document.body.setAttribute('page', '')
}