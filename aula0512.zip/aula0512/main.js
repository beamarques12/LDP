let listaRegistro = {
    ultimoIdGravado: 0,
    pessoas:[{id: 10, nome: "Beatriz Marques", telefone: '(11) 2405-9270'}]
}

function visualizar(pagina){
    document.body.setAttribute('page', '');
    if(pagina === 'cadastro'){
        document.getElementById('nome').focus(); //focus() = cursor do mouse
    }
}

//função para inserir os dados no LocalStorage

function inserirPessoa(nome,telefone){
    const id = listaRegistro.ultimoIdGravado + 1;
    listaRegistro.pessoas.push({id, nome, telefone});
    desenharTabela();
    visualizar('lista');
}

function desenharTabela(){
    const tbody = document.getElementById("listaRegistroBody");
    if(tbody){
        tbody.innerHTML = listaRegistro.pessoas.map(pessoa =>{
            return `<tr>
                    <td>${pessoa.id}</td>
                    <td>${pessoa.nome}</td>
                    <td>${pessoa.telefone}</td>
                    </tr>`}).join(''); //map(): duplica um array, mantendo a mesma estrutura, mas mudando o conteúdo (no caso, o id, o nome e o telefone dados)
                                    //join(): coloca um espaço em branco para separar do próximo registro
    }
}
function enviarDados(e){
    e.preventDefault();
    const dados = {id: document.getElementById('codigo').value, 
                    nome: document.getElementById('nome').value,
                    telefone: document.getElementById('telefone').value}
    console.log(dados);
}

window.addEventListener('load', () =>{
    desenharTabela();

    document.getElementById("cadastro-registros").addEventListener('submit', enviarDados);
});