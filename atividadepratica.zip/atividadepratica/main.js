let tentativas = 0;
const limiteTentativas = 3;

var listaRegistros = {
    ultimoIdGerado: 0,
    pessoas:[{}]
}

function validarFormulario() {
    // Validação para a primeira etapa
    let nome = document.getElementById('nome').value;
    let telefone = document.getElementById('telefone').value;
    let email = document.getElementById('email').value;
    let usuario = document.getElementById('username').value;
    let senha = document.getElementById('senha').value;
    let senha2 = document.getElementById('confirmarsenha').value;

    if (nome === "" || telefone === "" || email == "" || usuario === "" || senha === "" || senha2 === "") {
        alert("Por favor, preencha todos os campos na primeira etapa.");
        return false;
    }

    //validação do email
    let emailPadrao = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if(!email.match(emailPadrao)){
        alert("Por favor digite um e-mail válido");
        return false;
    }

    const emailExistente = listaRegistros.pessoas.some(pessoa => pessoa.email === email);
    if (emailExistente) {
        alert("Este email já está cadastrado. Por favor, use um email diferente.");
        return false;
    }

    //validação da senha (mínimo 8 caracteres)
    if(senha.length < 8 ){
        alert("A senha deve ter no minimo 8 caracteres");
        return false;
    }
    //verificando se as duas senhas são iguais
    if(senha !== senha2){
        alert("As senhas não coincidem. Por favor, tente novamente");
        return false;
    }

    return true

}


function limparDados(){
    document.getElementById('nome').value = "";
    document.getElementById('telefone').value = "";
    document.getElementById('email').value = "";
    document.getElementById('username').value = "";
    document.getElementById('senha').value = "";
}
//função para inserir os dados no LocalStorage


//função para ler os dados do local storage

function lerBD(){
    const lista = localStorage.getItem("pessoa");
    if(lista){
        listaRegistros = JSON.parse(lista);
        exibirDados();
    }
}

function visualizar(pagina, novo = false) {
    document.body.setAttribute("page", pagina);
    if (pagina === "cadastro") {
        if (novo) {
            limparDados();
            limparLocalStorage();
        }
        document.getElementById("tnome").focus();
    }
}

function enviarDados() {
    if (validarFormulario()) {
        const telefone = document.getElementById('telefone').value;
        const email = document.getElementById('email').value;
        const senha = document.getElementById('senha').value;
        const nome = document.getElementById('nome').value;
        const username = document.getElementById('username').value;
        localStorage.setItem('Telefone', telefone);
        localStorage.setItem('E-mail', email);
        localStorage.setItem('Senha', senha);
        localStorage.setItem('Nome', nome);
        localStorage.setItem('Username', username);

        limparDados();
        visualizar('lista');
    }
}

function limparLocalStorage() {
    localStorage.removeItem("pessoa");
}




function fazerLogin() {
    const usernameLogin = document.getElementById('usernameLogin').value;
    const senhaLogin = document.getElementById('senhaLogin').value;

    const usuarioEncontrado = listaRegistro.pessoas.find(usuario => usuario.username === usernameLogin);

    if (usuarioEncontrado) {
        if(usuarioEncontrado.senha === senhaLogin) {
            alert('Login bem-sucedido!');
            tentativas = 0;
            visualizar('lista');
        } else {
            tentativas++;

            if (tentativas === limiteTentativas) {
                alert('Você atingiu o limite de tentativas. Por favor, tente novamente mais tarde.');

            } else {
                alert(`Senha incorreta. Tentativa ${tentativas}/${limiteTentativas}.`);
            }
        }
    } else {
        alert('Email não encontrado. Por favor, verifique suas credenciais.');
    }
}

function exibirDados() {
    if (validarFormulario()){
    const nome = localStorage.getItem('txtNome');
    const prontuario = localStorage.getItem('txtProntuario');
    const turma = localStorage.getItem('txtTurma');
  
    
    const textoDiv = document.getElementById('texto');
    textoDiv.innerHTML = 'Dados do aluno' + '<br>' +
                         'Nome: ' + nome + '<br>' +
                        'Prontuario: ' + prontuario + '<br>' +
                        'Turma: ' + turma;
    }
  }

function redirecionar() {
    if (validarFormulario() == true) {
        visualizar('login');
    }
}

function initializePage() {
    lerBD();
    document.querySelector('button[name="btncadastra"]').addEventListener('click', enviarDados);
}

window.onload = initializePage;
